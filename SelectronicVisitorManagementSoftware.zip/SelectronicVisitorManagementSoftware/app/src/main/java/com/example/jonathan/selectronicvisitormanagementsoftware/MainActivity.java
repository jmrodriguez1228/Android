package com.example.jonathan.selectronicvisitormanagementsoftware;

import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends WelcomeScreen {

    protected FirebaseDatabase firebaseDatabase;
    protected DatabaseReference firebaseDatabaseReference;

    private AppCompatButton logInButton2;
    private EditText editTextFirstName;
    private EditText editTextLastName;
    private EditText editTextCompany;
    private EditText editTextEMail;
    private EditText editTextPhone;
    private FloatingActionButton fabSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        hideSystemUI();
        findViewById(R.id.mainLayout).requestFocus();

        firebaseDatabase = FirebaseDatabase.getInstance();
        firebaseDatabaseReference = firebaseDatabase.getReference().child("Visitors");

        logInButton2 = (AppCompatButton) findViewById(R.id.idLogInButton2);

        editTextFirstName = (EditText) findViewById(R.id.idEditTextFirstName);
        editTextLastName = (EditText) findViewById(R.id.idEditTextLastName);
        editTextCompany = (EditText) findViewById(R.id.idEditTextCompany);
        editTextEMail = (EditText) findViewById(R.id.idEditTextEMail);
        editTextPhone = (EditText) findViewById(R.id.idEditTextPhone);
        //ToDo: Find a way to extract time

        //ToDo: You can add functionality here to restrict sending to database based on the text input
        //You can also explore the material design options for the edittext
        //You should be able to extract time as well
        logInButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                VisitorInfo visitorInfo = new VisitorInfo(editTextFirstName.getText().toString(), editTextLastName.getText().toString(),
                        editTextCompany.getText().toString(), editTextEMail.getText().toString(), editTextPhone.getText().toString());
                firebaseDatabaseReference.push().setValue(visitorInfo);

                Intent intent = new Intent(getApplicationContext(), LoggedInScreen.class);
                intent.putExtra("extraFirstName", editTextFirstName.getText().toString());
                intent.putExtra("extraLastName", editTextLastName.getText().toString());
                intent.putExtra("extraCompany", editTextCompany.getText().toString());
                intent.putExtra("extraEMail", editTextCompany.getText().toString());
                intent.putExtra("extraPhone", editTextPhone.getText().toString());

                editTextFirstName.setText("");
                editTextLastName.setText("");
                editTextCompany.setText("");
                editTextEMail.setText("");
                editTextPhone.setText("");

                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
            }
        });

        fabSettings = (FloatingActionButton) findViewById(R.id.idFabSettings);

        fabSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Report1.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    private void hideSystemUI() {
        // Enables regular immersive mode.
        // For "lean back" mode, remove SYSTEM_UI_FLAG_IMMERSIVE.
        // Or for "sticky immersive," replace it with SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        // Set the content to appear under the system bars so that the
                        // content doesn't resize when the system bars hide and show.
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // Hide the nav bar and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

}
