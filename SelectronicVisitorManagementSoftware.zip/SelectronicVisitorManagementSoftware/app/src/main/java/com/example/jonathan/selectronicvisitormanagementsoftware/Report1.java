package com.example.jonathan.selectronicvisitormanagementsoftware;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;

public class Report1 extends MainActivity {

    private RecyclerView visitorsRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report1);

        visitorsRecyclerView = (RecyclerView) findViewById(R.id.idRecyclerViewVisitors);
        visitorsRecyclerView.setHasFixedSize(true);
        visitorsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<VisitorInfo, VisitorsViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<VisitorInfo, VisitorsViewHolder>(
                VisitorInfo.class, R.layout.recyclerview_visitors_row, VisitorsViewHolder.class, firebaseDatabaseReference) {
            @Override
            protected void populateViewHolder(VisitorsViewHolder viewHolder, VisitorInfo model, int position) {
                viewHolder.setDetails(getApplicationContext(), model.getFirstName(), model.getLastName(), model.getCompany(), model.geteMail(), model.getPhoneNumber());
            }
        };
        visitorsRecyclerView.setAdapter(firebaseRecyclerAdapter);
    }

    //ToDo: Investigate why this activity retains landscape mode while in lollipop it goes back to portrait
}
