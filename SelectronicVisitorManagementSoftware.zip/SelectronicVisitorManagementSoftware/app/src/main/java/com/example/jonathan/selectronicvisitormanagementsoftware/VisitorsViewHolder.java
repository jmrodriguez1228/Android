package com.example.jonathan.selectronicvisitormanagementsoftware;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

public class VisitorsViewHolder extends RecyclerView.ViewHolder {

    private View view;

    public VisitorsViewHolder(View itemView) {
        super(itemView);
        this.view = itemView;
    }

    //set the details to recyclerview_visitors_row
    public void setDetails(Context context, String firstName, String lastName, String company,
                           String eMail, String phoneNumber) {
        //find the views from recyclerview_visitors_row
        TextView fName = view.findViewById(R.id.idTextViewFirstName);
        TextView lName = view.findViewById(R.id.idTextViewLastName);
        TextView comp = view.findViewById(R.id.idTextViewCompany);
        TextView email = view.findViewById(R.id.idTextViewEMail);
        TextView pNumber = view.findViewById(R.id.idTextViewPhoneNumber);
        //set the text of the TextViews obtained
        fName.setText(firstName);
        lName.setText(lastName);
        comp.setText(company);
        email.setText(eMail);
        pNumber.setText(phoneNumber);
    }
}
