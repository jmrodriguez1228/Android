package com.example.jonathan.selectronicvisitormanagementsoftware;

import android.content.Context;
import android.content.Intent;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.Fade;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

public class LoggedInScreen extends WelcomeScreen {

    private TextView loggedInFirstName;
    private ConstraintLayout layoutLoggedInScreen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logged_in_screen);

        Intent intent = getIntent();

        String firstName = intent.getStringExtra("extraFirstName");

        loggedInFirstName = (TextView) findViewById(R.id.idLoggedInFirstName);
        loggedInFirstName.setText(firstName);

        layoutLoggedInScreen = (ConstraintLayout) findViewById(R.id.idLoggedInScreen);

        layoutLoggedInScreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), WelcomeScreen.class);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
            }
        });
    }
}
