package com.example.jonathan.selectronicvisitormanagementsoftware;

public class VisitorInfo {

    private String firstName;
    private String lastName;
    private String company;
    private String eMail;
    private String phoneNumber;

    public VisitorInfo() {}

    public VisitorInfo(String firstName, String lastName, String company, String eMail, String phoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.company = company;
        this.eMail = eMail;
        this.phoneNumber = phoneNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
